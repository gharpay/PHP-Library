<?php
define("USERNAME",""); // add your username here;
define("PASSWORD",""); // add password here;
define("URL","http://services.gharpay.in"); //Your web service URL goes here;
define("ERROR_ON",FALSE); //if you are developing app turn this to TRUE to enable error reporting.
?>